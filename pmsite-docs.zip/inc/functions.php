<?php
/** Functions **/

function pmsite_docs_is_doc_cpt(){
    return 'doc' === get_post_type();
}
